#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <queue>
#include <set>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>
#include <ctime>

using namespace std;

struct Node {
    string MID;
    vector<Node*> adj;
    vector<string> relation;
};


unordered_map<string, Node*> graph_map;
unordered_map<string, string> mid2name;

// Function to load mid2name.tsv
void loadMid2Name(const string& filename) {
    ifstream infile(filename);

    string line;
    while (getline(infile, line)) {
        string MID = line.substr(0, line.find("\t"));
        string remain = line.substr(line.find("\t") + 1, line.length() - MID.length());
        string name = remain.substr(0, remain.find("\t"));
        mid2name[MID] = name;
    }

    infile.close();
}

// Function to taking freebase's rows and creating graph
void loadFreebase(const string& filename) {
    ifstream infile(filename);

    string line;
    while (getline(infile, line)) {
        string ent1 = line.substr(0, line.find("\t"));
        string remain = line.substr(line.find("\t") + 1, line.length() - ent1.length());
        string relationship = remain.substr(0, remain.find("\t"));
        remain = remain.substr(remain.find("\t") + 1, remain.length() - relationship.length());
        string ent2 = remain.substr(0, remain.find("\r"));//this line is fixed it was wrong in skeleton.cpp we discussed in whatsapp group chat

        Node* ent1_node, *ent2_node;

        if (graph_map.find(ent1) == graph_map.end()) {
            ent1_node = new Node;
            ent1_node->MID = ent1;
            graph_map[ent1] = ent1_node;
        } else {
            ent1_node = graph_map[ent1];
        }

        if (graph_map.find(ent2) == graph_map.end()) {
            ent2_node = new Node;
            ent2_node->MID = ent2;
            graph_map[ent2] = ent2_node;
        } else {
            ent2_node = graph_map[ent2];
        }

        ent1_node->adj.push_back(ent2_node);
        ent1_node->relation.push_back(relationship);

        ent2_node->adj.push_back(ent1_node);
        ent2_node->relation.push_back(relationship);
    }

    infile.close();
}

// Part 1: Print neighbors of MID
void printNeighbors(const string& mid) {
    
    Node* node = graph_map[mid];
    unordered_set<string> printed_neighbors;
    cout << node->adj.size() <<" neighbors" << endl;
    for (int i = 0; i < node->adj.size(); ++i) {
        string neighbor_mid = node->adj[i]->MID;
        string relationship = node->relation[i];
        if (printed_neighbors.find(neighbor_mid + relationship) == printed_neighbors.end()) {
            cout << neighbor_mid << " " << mid2name[neighbor_mid] << endl;
            printed_neighbors.insert(neighbor_mid + relationship);
        }
    }
}

// Part 2: Find the most central 10 entities
void findMostCentralEntities() {
    vector<pair<int, string>> centrality;
    for (const auto& pair : graph_map) {
        centrality.push_back({pair.second->adj.size(), pair.first});
    }
    sort(centrality.rbegin(), centrality.rend()); // reverse sorting which means a>b>c
    for (int i = 0; i < 10; ++i) {
        cout << centrality[i].second << " " << mid2name[centrality[i].second] << " " << centrality[i].first << " neighbors" << endl;
    }
}

// Part 3: Find shortest distance between two MIDs
void findShortestPath(const string& mid1, const string& mid2) {
  
    queue<pair<Node*, vector<Node*>>> nodesToVisit;
    set<string> visitedMIDs;

    // BFS from the mid1
    nodesToVisit.push({graph_map[mid1], {}});
    visitedMIDs.insert(mid1);
    while (!nodesToVisit.empty()) {
        pair<Node*, vector<Node*>> frontPair = nodesToVisit.front();
        Node* currentNode = frontPair.first;
    vector<Node*> currentPath = frontPair.second;
        nodesToVisit.pop();

        // Add the current node to the path
        currentPath.push_back(currentNode);

        // Check if we found the target
        if (currentNode->MID == mid2) {
            cout << "Distance: " << currentPath.size() - 1 << endl;
            for (Node* node : currentPath) {
                cout << node->MID << " " << mid2name[node->MID] << endl;
            } 
            
            return;
        }

        // Push all unvisited neighbors to queue and also insert them into visitedMIDs
        for (Node* neighbor : currentNode->adj) {
            if (visitedMIDs.find(neighbor->MID) == visitedMIDs.end()) {
                visitedMIDs.insert(neighbor->MID);
                nodesToVisit.push({neighbor, currentPath});
            }
        }
    }

    
}

int main(int argc, char* argv[]) {

  //  clock_t start = clock();
    string command = argv[1];
    
    loadMid2Name("mid2name.tsv");
    loadFreebase("freebase.tsv");

    if (command == "part1") {
        string mid = argv[2];
        printNeighbors(mid);
    } else if (command == "part2") {
        findMostCentralEntities();
    } else if (command == "part3") {
        string mid1 = argv[2];
        string mid2 = argv[3];
        findShortestPath(mid1, mid2);
    } 
    
   // clock_t end = clock();
   // double duration = double(end - start) / CLOCKS_PER_SEC;

    
   // cout << "Execution time: " << duration << " seconds" << endl;

    return 0;
}
